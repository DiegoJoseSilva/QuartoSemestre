/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjpetshop_poo2_20250818;

/**
 *
 * @author IFTM
 */
public class PrjPetShop_POO2_20250818 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
