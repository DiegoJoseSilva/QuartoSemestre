/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjtestejavaforms.classes;

import com.mycompany.prjtestejavaforms.objetos.DadosEntradaEqSegGrau;
import com.mycompany.prjtestejavaforms.objetos.DadosSaidaEqSegGrau;

/**
 *
 * @author IFTM
 */
public class CalculadoraEqSegGrau {
    public void calcularDelta(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds){
        ds.setDelta(de.getB()*de.getB() - 4*de.getA()*de.getC());     
    }
    
    public void calcularX1(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds){
        ds.setX1L((-1*de.getB() + ds.getDelta())/2*de.getA());
    }
    
    public void calcularX2(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds){
        ds.setX2L((-1*de.getB() - ds.getDelta())/2*de.getA());
    }
    
    public void Xvertice(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds){
        ds.setxV(- 1 * de.getB() / 2*de.getA());
    }
    
    public void Yvertice(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds){
        ds.setyV(- 1 * ds.getDelta() / 4*de.getA());
    }
    
}
