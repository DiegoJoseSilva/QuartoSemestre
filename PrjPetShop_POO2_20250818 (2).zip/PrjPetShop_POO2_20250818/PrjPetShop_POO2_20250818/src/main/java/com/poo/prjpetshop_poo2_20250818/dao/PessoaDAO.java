package com.poo.prjpetshop_poo2_20250818.dao;

import com.poo.prjpetshop_poo2_20250818.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoaDAO {
    Connection conn;
    //ManipulaData md;
    
    public PessoaDAO(){
        conn = new Conexao().conectar();
    }
    public Pessoa salvar(Pessoa p){
         try{
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO pessoa(nome, cpf, data_nascimento) values (? ? ?)", 
                     statement.RETURN_GENERATED_KEYS);
             stmt.setString(1, p.getNome());
             stmt.setString(2, p.getCpf());
             stmt.setString (3, p.getData_nasc());
             stmt.execute();
             ResultSet rs = stmt.getGenerateKeys();
             if(rs.next()){
                 p.setIdpessoa(rs.getInt("idpessoa"));
             }
             else{
                 p.setIdpessoa(-1);
             }
         }
         catch(SQLException ex){
             ex.printStackTrace();
         }
         return p;
    }
    
}
