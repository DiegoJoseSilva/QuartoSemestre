package com.poo.prjpetshop_poo2_20250818.objects;

public class Pets {
    
}
