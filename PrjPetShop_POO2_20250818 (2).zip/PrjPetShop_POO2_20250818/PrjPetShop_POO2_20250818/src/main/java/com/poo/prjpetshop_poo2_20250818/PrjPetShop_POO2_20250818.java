/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjpetshop_poo2_20250818;

import com.poo.prjpetshop_poo2_20250818.util.Conexao;

/**
 *
 * @author IFTM
 */
public class PrjPetShop_POO2_20250818 {

    public static void main(String[] args) {
        new Conexao().conectar();
    }
}
